
export default function Home() {
  return (
    <main className="min-h-screen bg-white text-gray-900 p-6">
      <div className="max-w-4xl mx-auto space-y-10">
        <header className="text-center">
          <h1 className="text-4xl font-bold mb-2">Match-A-Maid Namibia</h1>
          <p className="text-lg text-gray-600">Connecting trusted housekeepers with homes & businesses across Namibia</p>
        </header>

        <section className="grid md:grid-cols-2 gap-6">
          <div className="p-6 rounded-2xl shadow-md border">
            <h2 className="text-2xl font-semibold mb-4">Need a Housekeeper?</h2>
            <p className="mb-4">Post your job details and let us connect you with reliable, verified housekeepers.</p>
            <a 
              href="https://forms.gle/your-employer-form-link" 
              target="_blank" 
              className="inline-block px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700"
            >
              Post a Job
            </a>
          </div>

          <div className="p-6 rounded-2xl shadow-md border">
            <h2 className="text-2xl font-semibold mb-4">Looking for Work?</h2>
            <p className="mb-4">Apply to be matched with cleaning jobs in your area. Start earning today!</p>
            <a 
              href="https://forms.gle/your-housekeeper-form-link" 
              target="_blank" 
              className="inline-block px-4 py-2 bg-green-600 text-white rounded-xl hover:bg-green-700"
            >
              Apply for a Job
            </a>
          </div>
        </section>

        <section className="text-center">
          <h3 className="text-xl font-semibold mb-2">How It Works</h3>
          <p className="text-gray-700 max-w-2xl mx-auto">
            We collect job and applicant info, match them based on location, availability and skills, then notify both parties. Once a match is made, each party pays a small fee for the connection. It’s simple, fast and effective.
          </p>
        </section>

        <footer className="text-center text-sm text-gray-500 border-t pt-4">
          &copy; {new Date().getFullYear()} Match-A-Maid Namibia. All rights reserved.
        </footer>
      </div>
    </main>
  );
}
